function formValidation()  
{  
var fname = document.registration.fname; 
var lname = document.registration.lname;
var uemail = document.registration.email; 
var passid = document.registration.passid;  
var cpassid = document.registration.cpassid; 
var uname = document.registration.username;  
var uzip = document.registration.zip;  
if(fname_validation(fname,5,12))  
{
if(lname_validation(lname,5,12))  
{ 
if(ValidateEmail(uemail))  
{	
if(passid_validation(passid,7,12))  
{ 
if(cpassid_validation(cpassid,7,12))  
{  
if(allLetter(uname))  
{  

}  
}  
}   
}  
}    
}  
return false;  
  
} function fname_validation(fname,mx,my)  
{  
var fname_len = fname.value.length;  
if (fname_len == 0 || fname_len >= my || fname_len < mx)  
{  
alert("First Name should not be empty / length be between "+mx+" to "+my);  
fname.focus();  
return false;  
}  
return true;  
} 
function lname_validation(lname,mx,my)  
{  
var lname_len = lname.value.length;  
if (lname_len == 0 || lname_len >= my || lname_len < mx)  
{  
alert("Last Name should not be empty / length be between "+mx+" to "+my);  
lname.focus();  
return false;  
}  
return true;  
} 
function passid_validation(passid,mx,my)  
{  
var passid_len = passid.value.length;  
if (passid_len == 0 ||passid_len >= my || passid_len < mx)  
{  
alert("Password should not be empty / length be between "+mx+" to "+my);  
passid.focus();  
return false;  
}  
return true;  
}  
function cpassid_validation(cpassid,mx,my)  
{  
var cpassid_len = cpassid.value.length;  
if (cpassid_len == 0 ||cpassid_len >= my || cpassid_len < mx)  
{  
alert("Password should not be empty / length be between "+mx+" to "+my);  
cpassid.focus();  
return false;  
}  
return true;  
}  
function allLetter(uname)  
{   
var letters = /^[A-Za-z]+$/;  
if(uname.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('Username must have alphabet characters only');  
uname.focus();  
return false;  
}  
}  
function alphanumeric(uadd)  
{   
var letters = /^[0-9a-zA-Z]+$/;  
if(uadd.value.match(letters))  
{  
return true;  
}  
else  
{  
alert('User address must have alphanumeric characters only');  
uadd.focus();  
return false;  
}  
}  
function countryselect(ucountry)  
{  
if(ucountry.value == "Default")  
{  
alert('Select your country from the list');  
ucountry.focus();  
return false;  
}  
else  
{  
return true;  
}  
}  
function allnumeric(uzip)  
{   
var numbers = /^[0-9]+$/;  
if(uzip.value.match(numbers))  
{  
return true;  
}  
else  
{  
alert('ZIP code must have numeric characters only');  
uzip.focus();  
return false;  
}  
}  
function ValidateEmail(uemail)  
{  
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
if(uemail.value.match(mailformat))  
{  
return true;  
}  
else  
{  
alert("You have entered an invalid email address!");  
uemail.focus();  
return false;  
}  
} 