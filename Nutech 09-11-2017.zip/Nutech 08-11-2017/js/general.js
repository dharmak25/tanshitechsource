$(document).ready(function() {
	$("ul li a").on("click", function(){  
		$("#content").load($(this).attr("page"));
		return false;

    });
});